**02.04.21 V0.1.0b**  
Initial prototype. A single-channel transmission with single frequency activation.  

**02.09.21 V0.1.1b**  
Initial prototype. Update from single-channel to dual-channel.  

**02.13.21 V0.1.2b**  
Initial prototype. Update to eight-channel transmission.  

**02.13.21 V0.1.3**  
Basic implementation. Adjustable channel transmission with sound marks.  

**02.27.21 V0.1.4**   
Add receiver status.   

**03.01.21 V0.2.0**   
Adaptive channel transmission.  

**03.05.21 V0.3.0**  
Two receiving modes were defined.  

**03.06.21 V0.3.1**  
Changed the frequencies selection to improve the accuracy of the sound marks.  

**03.10.21 V0.3.1**  
Changed the frequencies selection to improve the accuracy of the sound marks.  

**03.10.21 V0.3.2**  
The audio processing flow of the receiver was modified.  
Cyclic redundancy check was implemented.  

**03.13.21 V0.3.3**  
Fix the ASCII-to-binary bug.  

**03.16.21 V0.3.4**  
Added `clear_session()` method to receive multiple transmission during standby.  

**03.21.21 V0.4.0**  
Improved the code interface.  
Added utility methods (gets and sets).  

**03.22.21 V1.0.0**  
Restructured the project according to PyPi specifications.   

**03.24.21 V1.0.1**  
Bugfixes  
Improved exception handles  

**04.01.21 V1.1.0**  
Compatible to any audio backends as long as it provides buffered audio analysis.  
